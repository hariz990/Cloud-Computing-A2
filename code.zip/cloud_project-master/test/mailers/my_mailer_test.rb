require 'test_helper'

class MyMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
