require 'test_helper'

class DislikeBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
