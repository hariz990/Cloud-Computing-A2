class DislikeBook < ApplicationRecord
end
