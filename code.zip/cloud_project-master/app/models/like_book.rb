class LikeBook < ApplicationRecord
end
