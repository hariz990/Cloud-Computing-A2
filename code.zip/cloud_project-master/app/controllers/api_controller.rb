class ApiController < ApplicationController
end
