class ApplicationMailer < ActionMailer::Base
  # default from: "some_email@example.com"
  layout 'mailer'
end